package metrics

import (
	"github.com/fatedier/frp/models/metrics/aggregate"
)

var EnableMem = aggregate.EnableMem
var EnablePrometheus = aggregate.EnablePrometheus
